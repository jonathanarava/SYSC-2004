import java.util.List;
import java.util.Random;
import java.util.Iterator;
/**
 * Write a description of class Animal here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public abstract class Animal
{
    // instance variables - replace the example below with your own
    private int age;
    private boolean alive; 
    private Location location;
    private Field field;
    
    private int MAX_AGE =0;
    private int BREEDING_AGE=0;
    private int MAX_LITTER_SIZE=0;
    private double BREEDING_PROBABILITY=0.0;
    
    private List<Animal> animals;
    
    Random rand = Randomizer.getRandom();

    /**
     * Constructor for objects of class Animal
     */
    public Animal(boolean randomAge, Field field,Location location)
    {
        // initialise instance variables
        age = 0;
        alive = true;
        this.field = field; 
       setLocation(location);
        if(randomAge){
            age = rand.nextInt(getMAX_AGE());
    }
  }
  
      /**
     * Place the rabbit at the new location in the given field.
     * @param newLocation The rabbit's new location.
     */
    public void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    public boolean isAlive(){
        return alive;
    }
    
      /**
     * Indicate that the rabbit is no longer alive.
     * It is removed from the field.
     */
    public void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }
    
      /**
     * A rabbit can breed if it has reached the breeding age.
     * @return true if the rabbit can breed, false otherwise.
     */
    public boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
    
      /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    public int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
    
    public void incrementAge(){
        age++;
        if(age> getMAX_AGE()){
            setDead();
    }
   }
   
   public Location getLocation(){
       return location;
    }
    
    public abstract int getMAX_AGE();
    
    public abstract int getBreedingAge();
    
    public abstract int getLitterSize();
    
     public abstract double getBreedingProb();
    
   public abstract void act(List<Animal> newAnimals);
 

}
